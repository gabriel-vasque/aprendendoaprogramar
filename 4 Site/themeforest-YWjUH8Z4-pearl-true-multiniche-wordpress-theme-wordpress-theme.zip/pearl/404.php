<?php
$error_page_style = pearl_404_style();
get_template_part('partials/404/' . $error_page_style);
