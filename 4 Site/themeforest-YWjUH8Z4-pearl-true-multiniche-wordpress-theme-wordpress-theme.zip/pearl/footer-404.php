        </div> <!-- id wrapper closed-->
        <?php do_action('pearl_before_footer'); ?>
        <?php wp_footer(); ?>
    </body>
</html>