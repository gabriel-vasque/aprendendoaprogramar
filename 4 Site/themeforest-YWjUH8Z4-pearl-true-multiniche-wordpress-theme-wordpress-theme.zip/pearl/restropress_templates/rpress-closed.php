<div class="fancybox-main rpress-store-closed">
	<div class="fancybox-first">
		<div class="view-food-item-wrap">
			<div class="row">
				<div class="rp-col-md-12">
					<h3 class="text-center">
						{StoreClosed}
					</h3>
				</div>
			</div>
		</div>
	</div>
</div>
	