<?php //upd
$color = rpress_get_option( 'checkout_color', 'red' );
?>
<div class="view-food-item-wrap">
	<form id="fooditem-details" class="row">
		{Formatted_Cats}
	</form>
	<div class="clear"></div>	
	<div class="<?php echo esc_attr($color); ?> ">
		<a href="#" class="special-instructions-link">
			<?php echo apply_filters( 'rpress_special_instruction_text', __( 'Special Instructions?', 'pearl') ); ?> 
		</a>
		<textarea placeholder="<?php echo __( 'Add Instructions...', 'pearl' ) ?>" class="rp-col-md-12 special-instructions " name="special_instruction"></textarea>
</div>