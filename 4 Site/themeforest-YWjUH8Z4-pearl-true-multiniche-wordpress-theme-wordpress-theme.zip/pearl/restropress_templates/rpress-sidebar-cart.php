<?php $class = rpress_get_cart_quantity() == 0 ? 'no-items' : ''; ?>
<div class="rp-col-lg-3 rp-col-md-3 rp-col-sm-12 rp-col-xs-12 pull-right rpress-sidebar-cart item-cart sticky-sidebar">
    <div class="rpress-mobile-cart-icons <?php echo esc_attr($class); ?>">
        <i class='fa fa-shopping-cart' aria-hidden='true'></i>
        <span class='rpress-cart-badge rpress-cart-quantity'>
            <?php echo rpress_get_cart_quantity(); ?>
        </span>
    </div>
    <div class='rpress-sidebar-main-wrap'>
        <i class='fa fa-times close-cart-ic' aria-hidden='true'></i>
        <div class="rpress-sidebar-cart-wrap">
            <?php echo rpress_shopping_cart(); ?>
        </div>
    </div>
</div>