<?php
/**
 * This template is used to display the purchase summary with [rpress_receipt]
 */
global $rpress_receipt_args;

$payment   = get_post( $rpress_receipt_args['id'] );

if( empty( $payment ) ) : ?>

	<div class="rpress_errors rpress-alert rpress-alert-error">
		<?php _e( 'The specified receipt ID appears to be invalid', 'pearl' ); ?>
	</div>

<?php
return;
endif;

$meta      		= rpress_get_payment_meta( $payment->ID );
$delivery_date   = get_post_meta( $payment->ID, '_rpress_delivery_date', true );
$cart      		= rpress_get_payment_meta_cart_details( $payment->ID, true );
$user      		= rpress_get_payment_meta_user_info( $payment->ID );
$email     		= rpress_get_payment_user_email( $payment->ID );
$status    		= rpress_get_payment_status( $payment, true );
$order_note	  = get_post_meta( $payment->ID, '_rpress_order_note', true );
$deliver_type = rpress_get_payment_meta( $payment->ID, '_rpress_delivery_type' );
$deliver_time = rpress_get_payment_meta( $payment->ID, '_rpress_delivery_time' );
$time_text		= $deliver_type == 'pickup' ? __( 'Pickup Time', 'pearl' ) : __( 'Delivery Time', 'pearl' );
?>
<table id="rpress_purchase_receipt" class="rpress-table">
	<thead>
		<?php do_action( 'rpress_payment_receipt_before', $payment, $rpress_receipt_args ); ?>

		<?php if ( filter_var( $rpress_receipt_args['payment_id'], FILTER_VALIDATE_BOOLEAN ) ) : ?>
		<tr>
			<th><strong><?php _e( 'Order#', 'pearl' ); ?>:</strong></th>
			<th><?php echo rpress_get_payment_number( $payment->ID ); ?></th>
		</tr>
		<?php endif; ?>
	</thead>

	<tbody>

		<tr>
			<td class="rpress_receipt_payment_status"><strong><?php _e( 'Order Status', 'pearl' ); ?>:</strong></td>
			<td class="rpress_receipt_payment_status <?php echo strtolower( $status ); ?>"><?php echo wp_kses_post($status); ?></td>
		</tr>

		<tr>
			<td class="rpress_receipt_delivery_type"><strong><?php _e( 'Order Type', 'pearl' ); ?>:</strong></td>
			<td class="rpress_receipt_delivery_type <?php echo strtolower( $deliver_type ); ?>"><?php echo ucfirst( $deliver_type ); ?></td>
		</tr>

		<?php if ( !empty( $delivery_date ) ) : ?>
			<tr>
				<td class="rpress_receipt_delivery_date"><strong><?php _e( 'Delivery Date', 'pearl' ); ?>:</strong></td>
				<td class="rpress_receipt_delivery_date"><?php echo date_i18n( get_option( 'date_format' ), strtotime( $delivery_date ) ); ?></td>
			</tr>
		<?php endif; ?>

		<tr>
			<td class="rpress_receipt_delivery_time"><strong><?php echo wp_kses_post($time_text); ?>:</strong></td>
			<td class="rpress_receipt_delivery_time"><?php echo wp_kses_post($deliver_time); ?></td>
		</tr>

		<?php if ( !empty( $order_note ) ) : ?>
			<tr>
			<td class="rpress_order_note"><strong><?php _e( 'Order Note', 'pearl' ); ?>:</strong></td>
			<td class="rpress_order_note"><?php echo wp_kses_post($order_note); ?></td>
		</tr>
		<?php endif; ?>

		<?php if ( filter_var( $rpress_receipt_args['payment_key'], FILTER_VALIDATE_BOOLEAN ) ) : ?>
			<tr>
				<td><strong><?php _e( 'Payment Key', 'pearl' ); ?>:</strong></td>
				<td><?php echo rpress_get_payment_meta( $payment->ID, '_rpress_payment_purchase_key', true ); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ( filter_var( $rpress_receipt_args['date'], FILTER_VALIDATE_BOOLEAN ) ) : ?>
		<tr>
			<td><strong><?php _e( 'Order Date', 'pearl' ); ?>:</strong></td>
			<td><?php echo date_i18n( get_option( 'date_format' ), strtotime( $meta['date'] ) ); ?></td>
		</tr>
		<?php endif; ?>

		<?php if ( ( $fees = rpress_get_payment_fees( $payment->ID, 'fee' ) ) ) : 
			foreach( $fees as $fee ) : ?>
			<tr>
				<td>
					<strong>
						<span class="rpress_fee_label"><?php echo esc_html( $fee['label'] ); ?></span>
					</strong>
				</td>
				<td>
					<span class="rpress_fee_amount"><?php echo rpress_currency_filter( rpress_format_amount( $fee['amount'] ) ); ?></span>
				</td>
			</tr>
			<?php endforeach; ?>
			
		<?php endif; ?>

		<?php if ( filter_var( $rpress_receipt_args['discount'], FILTER_VALIDATE_BOOLEAN ) && isset( $user['discount'] ) && $user['discount'] != 'none' ) : ?>
			<tr>
				<td><strong><?php _e( 'Discount(s)', 'pearl' ); ?>:</strong></td>
				<td><?php echo wp_kses_post($user['discount']); ?></td>
			</tr>
		<?php endif; ?>

		<?php if( rpress_use_taxes() ) : ?>
			<tr>
				<td><strong><?php _e( 'Tax', 'pearl' ); ?>:</strong></td>
				<td><?php echo rpress_payment_tax( $payment->ID ); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ( filter_var( $rpress_receipt_args['payment_method'], FILTER_VALIDATE_BOOLEAN ) ) : ?>
			<tr>
				<td><strong><?php _e( 'Payment Method', 'pearl' ); ?>:</strong></td>
				<td><?php echo rpress_get_gateway_checkout_label( rpress_get_payment_gateway( $payment->ID ) ); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ( filter_var( $rpress_receipt_args['price'], FILTER_VALIDATE_BOOLEAN ) ) : ?>
			<tr>
				<td><strong><?php _e( 'Total Price', 'pearl' ); ?>:</strong></td>
				<td><?php echo rpress_payment_amount( $payment->ID ); ?></td>
			</tr>

		<?php endif; ?>

		<?php do_action( 'rpress_payment_receipt_after', $payment, $rpress_receipt_args ); ?>
	</tbody>
</table>

<?php do_action( 'rpress_payment_receipt_after_table', $payment, $rpress_receipt_args ); ?>

<?php if ( filter_var( $rpress_receipt_args['products'], FILTER_VALIDATE_BOOLEAN ) ) : ?>
	<fieldset>
		<legend><?php echo apply_filters( 'rpress_payment_receipt_products_title', __( 'Items Ordered', 'pearl' ) ); ?></legend>

		<table id="rpress_purchase_receipt_products" class="rpress-table">
			<thead>
				<th><?php _e( 'Name', 'pearl' ); ?></th>
				<th><?php _e( 'Price', 'pearl' ); ?></th>
			</thead>
	
			<tbody>
			<?php if( $cart ) : ?>
				<?php
				//print_r($cart);
				foreach ( $cart as $key => $item ) : ?>
					<?php
						$row_price = array();
					 ?>
					<?php if( ! apply_filters( 'rpress_user_can_view_receipt_item', true, $item ) ) : ?>
						<?php continue; // Skip this item if can't view it ?>
					<?php endif; ?>
	
					<?php if( empty( $item['in_bundle'] ) ) : ?>
					<tr>
						<td>
							<?php
							$price_id       = rpress_get_cart_item_price_id( $item );
							?>
	
							<div class="rpress_purchase_receipt_product_name">
								<?php echo wp_kses_post($item['quantity']); ?> X <?php echo esc_html( $item['name'] ); ?> (<?php echo rpress_price( $item['id'] ); ?>)
								<?php
									if( is_array($item['item_number']['options']) &&
										!empty($item['item_number']['options']) ) {
										
										foreach( $item['item_number']['options'] as $k => $v ) {
											
											if ( isset( $v['price'] ) 
												&& !empty( $v['price'] ) ) {
												array_push( $row_price, $v['price'] );
											}
											
											if( !empty($v['addon_item_name']) ) {
												?>
												<br/>&nbsp;&nbsp;<small class="rpress-receipt-addon-item"><?php echo wp_kses_post($v['addon_item_name']); ?> (<?php echo rpress_currency_filter(rpress_format_amount($v['price'])); ?>)</small>
												<?php
											}
										}
									}
								?>
							</div>
	
	
						</td>
						<td>
							<?php if( empty( $item['in_bundle'] ) ) : // Only show price when product is not part of a bundle ?>
								<?php
								$addon_price = array_sum($row_price);
								$addon_price = $addon_price + $item[ 'price' ];
								?>
								<?php echo rpress_currency_filter( rpress_format_amount( $addon_price ) ); ?>
							<?php endif; ?>
						</td>
					</tr>
					<?php endif; ?>
				<?php endforeach; ?>
			<?php endif; ?>
	
			</tbody>
	
		</table>
	</fieldset>

<?php endif; ?>
