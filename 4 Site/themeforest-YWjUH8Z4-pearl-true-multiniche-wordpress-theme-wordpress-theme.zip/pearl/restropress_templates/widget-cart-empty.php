<?php 
	$cart_quantity = rpress_get_cart_quantity();
	$display       = $cart_quantity > 0 ? '' : ' style="display:none;"';
	$color = rpress_get_option( 'checkout_color', 'red' );
?>
<li class="cart_item empty"><?php echo rpress_empty_cart_message(); ?></li>
<?php if ( rpress_use_taxes() ) : ?>
<li class="cart_item rpress-cart-meta rpress_subtotal" style="display:none;"><?php echo __( 'Subtotal:', 'pearl' ). " <span class='subtotal'>" . rpress_currency_filter( rpress_format_amount( rpress_get_cart_subtotal() ) ); ?></span></li>
<li class="cart_item rpress-cart-meta rpress_cart_tax" style="display:none;"><?php _e( 'Estimated Tax:', 'pearl' ); ?> <span class="cart-tax"><?php echo rpress_currency_filter( rpress_format_amount( rpress_get_cart_tax() ) ); ?></span></li>
<?php endif; ?>

<?php if( apply_delivery_fee() ) : ?>
  <li class="cart_item rpress-cart-meta rpress_subtotal" style="display:none;"><?php _e( 'SubTotal:', 'pearl' ); ?> <span class="cart-sub-total <?php echo esc_attr($color); ?>"><?php echo rpress_currency_filter( rpress_format_amount( rpress_get_cart_subtotal() ) ); ?></span>
  </li>
<?php endif; ?>

<?php if ( get_delivery_fees() > 0 ) : ?>
  <li class="cart_item rpress-cart-meta rpress_delivery_fee" style="display:none;"><?php _e( 'Fee:', 'pearl' ); ?> <span class="rpress-delivery-fee <?php echo esc_attr($color); ?>"><?php echo rpress_currency_filter( rpress_format_amount( get_delivery_fees() ) ); ?></span>
<?php endif; ?>

<li class="cart_item rpress-cart-meta rpress_total 999" style="display:none;"><?php _e( 'Total (', 'pearl' ); ?><span class="rpress-cart-quantity" <?php echo wp_kses_post($display); ?>><?php echo wp_kses_post($cart_quantity); ?></span> <?php _e( ' Items)', 'pearl' ); ?><span class="cart-total <?php echo esc_attr($color); ?>"><?php echo rpress_currency_filter( rpress_format_amount( rpress_get_cart_total() ) ); ?></span></li>
<li class="delivery-items-options" style="display:none">
	<?php echo get_delivery_options( true ); ?>
</li>
<li class="cart_item rpress_checkout" style="display:none;"><a href="<?php echo rpress_get_checkout_uri(); ?>"><?php _e( 'Checkout', 'pearl' ); ?></a></li>