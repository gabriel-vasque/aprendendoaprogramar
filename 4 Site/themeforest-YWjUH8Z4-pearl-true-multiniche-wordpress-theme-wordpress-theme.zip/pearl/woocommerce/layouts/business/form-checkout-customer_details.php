<div class="col2-set" id="customer_details">
    <div class="col-1">
        <?php do_action( 'woocommerce_checkout_billing' ); ?>
    </div>

    <div class="col-2">
        <?php do_action( 'woocommerce_checkout_shipping' ); ?>
    </div>
</div>