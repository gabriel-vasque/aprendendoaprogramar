<div id="customer_details">
    <div class="checkout_billing_wrap">
        <?php do_action( 'woocommerce_checkout_billing' ); ?>
    </div>

    <div class="checkout_shipping_wrap">
        <?php do_action( 'woocommerce_checkout_shipping' ); ?>
    </div>
</div>