<div id="order_review" class="woocommerce-checkout-review-order">
    <h3><?php esc_html_e('Your order', 'pearl'); ?></h3>
    <div class="woocommerce-checkout-review-order-wrap">
        <?php do_action( 'woocommerce_checkout_order_review' ); ?>
    </div>
</div>