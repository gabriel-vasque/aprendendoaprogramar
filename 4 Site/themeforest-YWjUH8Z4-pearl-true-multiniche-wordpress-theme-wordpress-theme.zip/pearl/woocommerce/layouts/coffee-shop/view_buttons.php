<div class="woo_grid_view_button">
    <span class="woo_grid_view_title"><?php esc_html_e('View', 'pearl'); ?></span>
    <div class="shop_grid_button view_3">
        <span class="stmicon-grid_3_13"></span>
    </div>

    <div class="shop_grid_button view_4">
        <span class="stmicon-grid_4_13"></span>
    </div>
</div>